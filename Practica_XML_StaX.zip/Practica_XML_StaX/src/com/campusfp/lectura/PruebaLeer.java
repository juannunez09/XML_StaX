package com.campusfp.lectura;

import java.util.List;
import com.campusfp.lectura.Item;

public class PruebaLeer {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StaXParser parseLectura = new StaXParser();
		List<Item> solucion = parseLectura.leer("config.xml");
		for (Item item : solucion) {
            System.out.println(item);
        }
	}
}
